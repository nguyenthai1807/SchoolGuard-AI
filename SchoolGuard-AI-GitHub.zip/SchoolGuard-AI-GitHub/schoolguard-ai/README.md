# SchoolGuard AI – Frontend Demo

Giao diện demo quản lý cảnh báo an ninh trường học được xây dựng bằng React và Vite.

## Chức năng
- Danh sách cảnh báo và bảng thống kê.
- Tìm kiếm, lọc theo trạng thái, mức độ, loại cảnh báo và ngày.
- Xem chi tiết cảnh báo, cập nhật trạng thái và ghi chú xử lý.
- Lịch sử xử lý riêng với tìm kiếm, bộ lọc và chi tiết mở ngay bên dưới dòng được chọn.
- Lưu dữ liệu demo trên `localStorage` của trình duyệt.

> Đây là bản demo frontend; nguồn camera và dữ liệu AI thực tế chưa được kết nối.

## Chạy trên máy
Cần cài Node.js phiên bản LTS.

```bash
npm install
npm run dev
```

Mở địa chỉ Local được Vite in ra trong Terminal.

## Build để kiểm tra

```bash
npm run build
```
