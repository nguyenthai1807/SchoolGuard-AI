import React, { useMemo, useState } from 'react';
import {
  ShieldCheck, LayoutDashboard, BellRing, Camera, MapPin, Clock3,
  Search, SlidersHorizontal, ChevronDown, ChevronRight, AlertTriangle,
  CheckCircle2, CircleDot, History, X, Check, Play, ShieldAlert,
  Activity, Users, PackageSearch, CalendarDays, Filter, Plus, RefreshCw, FileText, ArrowUpDown
} from 'lucide-react';

const initialAlerts = [
  { id:'AL-1048', type:'Xâm nhập khu vực cấm', category:'intrusion', location:'Phòng thiết bị · Tầng 2', camera:'CAM-08', time:'08:42:16', date:'2026-10-17', severity:'Cao', status:'Chưa xử lý', description:'Phát hiện người xuất hiện trong khu vực hạn chế ngoài khung giờ cho phép.', confidence:96, history:[{time:'08:42:16', actor:'SchoolGuard AI', action:'Tạo cảnh báo', note:'Phát hiện người tại Phòng thiết bị · Tầng 2.'}] },
  { id:'AL-1047', type:'Tụ tập đông người', category:'crowd', location:'Hành lang A · Tầng 1', camera:'CAM-03', time:'08:36:02', date:'2026-10-17', severity:'Trung bình', status:'Đang xử lý', description:'Mật độ người tại hành lang cao hơn ngưỡng thông thường trong thời gian liên tục.', confidence:91, history:[{time:'08:36:02',actor:'SchoolGuard AI',action:'Tạo cảnh báo',note:'Mật độ người vượt ngưỡng.'},{time:'08:38:10',actor:'Nguyễn Minh An',action:'Xác nhận cảnh báo',note:'Đã tiếp nhận và đang kiểm tra camera.'},{time:'08:39:20',actor:'Nguyễn Minh An',action:'Chuyển sang đang xử lý',note:'Đang điều phối bảo vệ đến khu vực.'}] },
  { id:'AL-1046', type:'Đồ vật bỏ quên', category:'object', location:'Sảnh thư viện', camera:'CAM-12', time:'08:21:43', date:'2026-10-17', severity:'Thấp', status:'Đã hoàn tất', description:'Một vật thể được phát hiện đứng yên tại khu vực công cộng trong thời gian dài.', confidence:87, history:[{time:'08:21:43',actor:'SchoolGuard AI',action:'Tạo cảnh báo',note:'Phát hiện vật thể đứng yên.'},{time:'08:23:00',actor:'Trần Gia Huy',action:'Xác nhận cảnh báo',note:'Đã tiếp nhận.'},{time:'08:27:34',actor:'Trần Gia Huy',action:'Hoàn tất xử lý',note:'Đã kiểm tra, xác định là đồ dùng cá nhân và bàn giao.'}] },
  { id:'AL-1045', type:'Phát hiện té ngã', category:'fall', location:'Sân thể chất', camera:'CAM-05', time:'08:12:08', date:'2026-10-17', severity:'Cao', status:'Chưa xử lý', description:'AI phát hiện chuyển động có thể liên quan đến tình huống té ngã. Cần nhân viên xác minh.', confidence:82, history:[{time:'08:12:08',actor:'SchoolGuard AI',action:'Tạo cảnh báo',note:'Phát hiện chuyển động nghi ngờ té ngã; cần xác minh trực tiếp.'}] },
  { id:'AL-1044', type:'Chen lấn tại cổng', category:'crowd', location:'Cổng chính', camera:'CAM-01', time:'07:58:51', date:'2026-10-17', severity:'Trung bình', status:'Đã xác nhận', description:'Dòng người di chuyển dồn lại tại cổng chính vào giờ đến trường.', confidence:89, history:[{time:'07:58:51',actor:'SchoolGuard AI',action:'Tạo cảnh báo',note:'Phát hiện mật độ người tăng.'},{time:'08:00:12',actor:'Lê Hoàng Nam',action:'Xác nhận cảnh báo',note:'Đã tiếp nhận, đang đánh giá tình hình.'}] },
  { id:'AL-1043', type:'Xâm nhập khu vực cấm', category:'intrusion', location:'Phòng thí nghiệm', camera:'CAM-09', time:'07:42:19', date:'2026-10-17', severity:'Cao', status:'Đã hoàn tất', description:'Phát hiện chuyển động trong phòng thí nghiệm trước giờ mở cửa.', confidence:94, history:[{time:'07:42:19',actor:'SchoolGuard AI',action:'Tạo cảnh báo',note:'Chuyển động được phát hiện trong phòng thí nghiệm.'},{time:'07:44:01',actor:'Phạm Thu Hà',action:'Xác nhận cảnh báo',note:'Đã tiếp nhận.'},{time:'07:49:55',actor:'Phạm Thu Hà',action:'Hoàn tất xử lý',note:'Đã xác minh nhân viên được phân công có lịch vào sớm.'}] },
  { id:'AL-1042', type:'Đồ vật bỏ quên', category:'object', location:'Hành lang B · Tầng 2', camera:'CAM-06', time:'07:31:05', date:'2026-10-17', severity:'Thấp', status:'Cảnh báo sai', description:'Hệ thống nghi ngờ có vật thể bị bỏ quên ở hành lang.', confidence:74, history:[{time:'07:31:05',actor:'SchoolGuard AI',action:'Tạo cảnh báo',note:'Phát hiện vật thể đứng yên.'},{time:'07:34:40',actor:'Nguyễn Minh An',action:'Đánh dấu cảnh báo sai',note:'Xác minh vật thể là thùng rác cố định.'}] }
];

const statusOptions = ['Chưa xử lý','Đã xác nhận','Đang xử lý','Đã hoàn tất','Cảnh báo sai'];
const severityClass = s => s === 'Cao' ? 'high' : s === 'Trung bình' ? 'medium' : 'low';
const statusClass = s => ({'Chưa xử lý':'pending','Đã xác nhận':'ack','Đang xử lý':'progress','Đã hoàn tất':'done','Cảnh báo sai':'false'})[s] || 'pending';
const iconFor = category => category === 'intrusion' ? ShieldAlert : category === 'crowd' ? Users : category === 'object' ? PackageSearch : AlertTriangle;

function App() {
  const [alerts, setAlerts] = useState(() => {
    try { const saved = localStorage.getItem('schoolguard-alerts-v1'); return saved ? JSON.parse(saved) : initialAlerts; }
    catch { return initialAlerts; }
  });
  const [selectedId, setSelectedId] = useState('AL-1048');
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('Tất cả trạng thái');
  const [severityFilter, setSeverityFilter] = useState('Tất cả mức độ');
  const [typeFilter, setTypeFilter] = useState('Tất cả loại');
  const [dateFilter, setDateFilter] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [historyOnly, setHistoryOnly] = useState(false);
  const [currentPage, setCurrentPage] = useState('alerts');
  const [historyQuery, setHistoryQuery] = useState('');
  const [historyStatusFilter, setHistoryStatusFilter] = useState('Tất cả trạng thái');
  const [historyActorFilter, setHistoryActorFilter] = useState('Tất cả người xử lý');
  const [historyDateFilter, setHistoryDateFilter] = useState('');
  const [selectedHistoryKey, setSelectedHistoryKey] = useState(null);
  const [note, setNote] = useState('');
  const [toast, setToast] = useState('');
  const [mobileDetail, setMobileDetail] = useState(false);

  const selected = alerts.find(a => a.id === selectedId) || alerts[0];
  const filtered = useMemo(() => alerts.filter(a => {
    const q = query.trim().toLowerCase();
    return (!q || [a.id,a.type,a.location,a.camera].some(v => v.toLowerCase().includes(q))) &&
      (statusFilter === 'Tất cả trạng thái' || a.status === statusFilter) &&
      (severityFilter === 'Tất cả mức độ' || a.severity === severityFilter) &&
      (typeFilter === 'Tất cả loại' || a.type === typeFilter) &&
      (!dateFilter || a.date === dateFilter);
  }).sort((a,b) => (b.date+b.time).localeCompare(a.date+a.time)), [alerts,query,statusFilter,severityFilter,typeFilter,dateFilter]);

  const stats = [
    {label:'Tổng cảnh báo',value:alerts.length,icon:BellRing,tone:'blue'},
    {label:'Chưa xử lý',value:alerts.filter(a=>a.status==='Chưa xử lý').length,icon:AlertTriangle,tone:'red'},
    {label:'Đang xử lý',value:alerts.filter(a=>a.status==='Đang xử lý'||a.status==='Đã xác nhận').length,icon:Activity,tone:'amber'},
    {label:'Đã hoàn tất',value:alerts.filter(a=>a.status==='Đã hoàn tất').length,icon:CheckCircle2,tone:'green'}
  ];

  function persist(next) {
    setAlerts(next);
    try { localStorage.setItem('schoolguard-alerts-v1', JSON.stringify(next)); } catch {}
  }
  function updateStatus(newStatus) {
    if (!selected) return;
    const time = new Date().toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
    const actionMap = {'Đã xác nhận':'Xác nhận cảnh báo','Đang xử lý':'Chuyển sang đang xử lý','Đã hoàn tất':'Hoàn tất xử lý','Cảnh báo sai':'Đánh dấu cảnh báo sai','Chưa xử lý':'Đưa về chưa xử lý'};
    const historyItem = {time, actor:'Nhân viên trực ca', action:actionMap[newStatus] || 'Cập nhật trạng thái', note:note.trim() || `Trạng thái được cập nhật thành “${newStatus}”.`};
    const next = alerts.map(a => a.id === selected.id ? {...a,status:newStatus,history:[...a.history,historyItem]} : a);
    persist(next); setNote(''); setToast(`Đã cập nhật ${selected.id} thành “${newStatus}”`); setTimeout(()=>setToast(''),3000);
  }
  function clearFilters() { setQuery('');setStatusFilter('Tất cả trạng thái');setSeverityFilter('Tất cả mức độ');setTypeFilter('Tất cả loại');setDateFilter(''); }
  const historyEvents = useMemo(() => alerts.flatMap(alert => {
    let latestStatus = 'Chưa xử lý';
    return alert.history.map((entry, index) => {
      if (entry.action.includes('Xác nhận')) latestStatus = 'Đã xác nhận';
      if (entry.action.includes('đang xử lý')) latestStatus = 'Đang xử lý';
      if (entry.action.includes('Hoàn tất')) latestStatus = 'Đã hoàn tất';
      if (entry.action.includes('cảnh báo sai')) latestStatus = 'Cảnh báo sai';
      if (entry.action.includes('Đưa về chưa xử lý')) latestStatus = 'Chưa xử lý';
      if (index === alert.history.length - 1) latestStatus = alert.status;
      return { ...entry, alertId: alert.id, type: alert.type, location: alert.location, date: alert.date, status: latestStatus, key: `${alert.id}-${index}` };
    });
  }).sort((a,b) => (b.date + b.time).localeCompare(a.date + a.time)), [alerts]);
  const filteredHistoryEvents = useMemo(() => historyEvents.filter(event => {
    const q = historyQuery.trim().toLowerCase();
    return (!q || [event.alertId,event.type,event.location,event.actor,event.action,event.note].some(value => value.toLowerCase().includes(q))) &&
      (historyStatusFilter === 'Tất cả trạng thái' || event.status === historyStatusFilter) &&
      (historyActorFilter === 'Tất cả người xử lý' || event.actor === historyActorFilter) &&
      (!historyDateFilter || event.date === historyDateFilter);
  }), [historyEvents, historyQuery, historyStatusFilter, historyActorFilter, historyDateFilter]);
  const historyActors = [...new Set(historyEvents.map(event => event.actor))].sort((a,b)=>a.localeCompare(b,'vi'));
  const selectedHistoryEvent = historyEvents.find(event => event.key === selectedHistoryKey) || null;
  const Icon = selected ? iconFor(selected.category) : BellRing;

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><ShieldCheck size={25}/></div><div><strong>SchoolGuard <span>AI</span></strong><small>SMART CAMPUS SECURITY</small></div></div>
      <div className="school-switch"><div className="school-avatar">TH</div><div><b>Trường học thông minh</b><small>Cơ sở chính</small></div><ChevronDown size={16}/></div>
      <div className="nav-label">KHÔNG GIAN LÀM VIỆC</div>
      <nav>
        <button className="nav-item"><LayoutDashboard size={18}/> Tổng quan</button>
        <button className={`nav-item ${currentPage === 'alerts' ? 'active' : ''}`} onClick={() => setCurrentPage('alerts')}><BellRing size={18}/> Quản lý cảnh báo <span className="nav-count">{alerts.filter(a=>a.status==='Chưa xử lý').length}</span></button>
        <button className="nav-item" onClick={()=>{setToast('Camera trực tiếp chưa kết nối nguồn video thật');setTimeout(()=>setToast(''),2500)}}><Camera size={18}/> Camera trực tiếp <span className="live-dot"/></button>
        <button className={`nav-item ${currentPage === 'history' ? 'active' : ''}`} onClick={() => {setCurrentPage('history');setSelectedHistoryKey(null);}}><History size={18}/> Lịch sử xử lý</button>
      </nav>
      <div className="sidebar-bottom"><div className="system-card"><div className="system-top"><span className="green-dot"/> Hệ thống hoạt động</div><p>AI đang giám sát <b>12 camera</b></p><div className="system-bar"><span/></div><small>12/12 camera trực tuyến</small></div><div className="profile"><div className="profile-avatar">NA</div><div><b>Nguyễn Minh An</b><small>Nhân viên an ninh</small></div><ChevronDown size={16}/></div></div>
    </aside>

    <main className="main">
      <header className="topbar"><div className="breadcrumb">Không gian làm việc <ChevronRight size={14}/> <b>{currentPage === 'history' ? 'Lịch sử xử lý' : 'Quản lý cảnh báo'}</b></div><div className="top-actions"><div className="connection"><span className="green-dot"/> AI đang hoạt động</div><button className="icon-button" title="Thông báo"><BellRing size={18}/><i/></button><div className="top-avatar">NA</div></div></header>
      {currentPage === 'history' ? <>
        <section className="page-heading history-page-heading"><div><div className="eyebrow"><span/> TRUNG TÂM AN NINH</div><h1>Lịch sử xử lý</h1><p>Theo dõi toàn bộ thao tác tiếp nhận, xác minh và xử lý cảnh báo.</p></div><div className="heading-meta"><div className="date-chip"><History size={16}/><span>{historyEvents.length} hoạt động được ghi nhận</span></div><button className="outline-button" onClick={()=>{setHistoryQuery('');setHistoryStatusFilter('Tất cả trạng thái');setHistoryActorFilter('Tất cả người xử lý');setHistoryDateFilter('');setSelectedHistoryKey(null)}}><RefreshCw size={15}/> Đặt lại bộ lọc</button></div></section>
        <section className="history-stats-grid">
          <div className="history-stat-card"><span className="history-stat-icon blue"><History size={18}/></span><div><span>Tổng hoạt động</span><strong>{historyEvents.length}</strong></div></div>
          <div className="history-stat-card"><span className="history-stat-icon amber"><Activity size={18}/></span><div><span>Đang xử lý</span><strong>{alerts.filter(a=>a.status==='Đang xử lý'||a.status==='Đã xác nhận').length}</strong></div></div>
          <div className="history-stat-card"><span className="history-stat-icon green"><CheckCircle2 size={18}/></span><div><span>Đã hoàn tất</span><strong>{alerts.filter(a=>a.status==='Đã hoàn tất').length}</strong></div></div>
          <div className="history-stat-card"><span className="history-stat-icon red"><AlertTriangle size={18}/></span><div><span>Chưa xử lý</span><strong>{alerts.filter(a=>a.status==='Chưa xử lý').length}</strong></div></div>
        </section>
        <section className="history-panel">
          <div className="history-panel-heading"><div><h2><FileText size={19}/> Nhật ký hoạt động</h2><p>Lịch sử được tạo từ các thao tác trong hệ thống trên trình duyệt này.</p></div><span className="history-count-badge">{filteredHistoryEvents.length} kết quả</span></div>
          <div className="history-controls">
            <div className="search-box history-search"><Search size={17}/><input value={historyQuery} onChange={e=>setHistoryQuery(e.target.value)} placeholder="Tìm mã cảnh báo, sự kiện, người xử lý..."/>{historyQuery&&<button onClick={()=>setHistoryQuery('')}><X size={15}/></button>}</div>
            <label><span>Trạng thái</span><select value={historyStatusFilter} onChange={e=>setHistoryStatusFilter(e.target.value)}><option>Tất cả trạng thái</option>{statusOptions.map(status=><option key={status}>{status}</option>)}</select></label>
            <label><span>Người xử lý</span><select value={historyActorFilter} onChange={e=>setHistoryActorFilter(e.target.value)}><option>Tất cả người xử lý</option>{historyActors.map(actor=><option key={actor}>{actor}</option>)}</select></label>
            <label><span>Ngày</span><input type="date" value={historyDateFilter} onChange={e=>setHistoryDateFilter(e.target.value)}/></label>
          </div>
          <div className="history-table-wrap"><table className="history-table"><thead><tr><th>Mã cảnh báo</th><th>Sự kiện / thao tác</th><th>Thời gian</th><th>Người xử lý</th><th>Trạng thái</th><th></th></tr></thead><tbody>
            {filteredHistoryEvents.map(event=><React.Fragment key={event.key}>
              <tr className={selectedHistoryKey===event.key?'selected-history-row':''} onClick={()=>setSelectedHistoryKey(selectedHistoryKey===event.key?null:event.key)} aria-expanded={selectedHistoryKey===event.key} style={{cursor:'pointer'}}><td><span className="history-id">{event.alertId}</span><small>{event.location}</small></td><td><strong>{event.type}</strong><small className="history-action"><CircleDot size={11}/>{event.action}</small></td><td><span className="history-time"><Clock3 size={13}/>{event.time}</span><small>{event.date.split('-').reverse().join('/')}</small></td><td><span className="history-actor"><span>{event.actor==='SchoolGuard AI'?'AI':event.actor.split(' ').map(part=>part[0]).slice(-2).join('').toUpperCase()}</span>{event.actor}</span></td><td><span className={`status-pill ${statusClass(event.status)}`}>{event.status}</span></td><td><ChevronRight size={16} style={{transform:selectedHistoryKey===event.key?'rotate(90deg)':'none',transition:'transform .2s'}}/></td></tr>
              {selectedHistoryKey===event.key&&<tr className="history-detail-row"><td colSpan={6} style={{padding:'12px 16px 18px',background:'var(--surface, #f8fafc)'}}><div className="history-detail-card" style={{margin:0,boxShadow:'none'}}><div className="history-detail-title"><div><span>CHI TIẾT HOẠT ĐỘNG</span><h3>{event.action}</h3></div><button className="icon-button" onClick={(e)=>{e.stopPropagation();setSelectedHistoryKey(null)}} title="Đóng chi tiết"><X size={16}/></button></div><div className="history-detail-grid"><div><span>Mã cảnh báo</span><b>{event.alertId} · {event.type}</b></div><div><span>Thời gian ghi nhận</span><b>{event.date.split('-').reverse().join('/')} · {event.time}</b></div><div><span>Người thực hiện</span><b>{event.actor}</b></div><div><span>Trạng thái tại bản ghi</span><b><span className={`status-pill ${statusClass(event.status)}`}>{event.status}</span></b></div><div className="history-note-detail"><span>Ghi chú xử lý</span><p>{event.note || 'Không có ghi chú cho hoạt động này.'}</p></div></div></div></td></tr>}
            </React.Fragment>)}
          </tbody></table>{filteredHistoryEvents.length===0&&<div className="empty-state history-empty"><History size={25}/><b>Không tìm thấy hoạt động</b><span>Thử thay đổi từ khóa hoặc bộ lọc.</span><button onClick={()=>{setHistoryQuery('');setHistoryStatusFilter('Tất cả trạng thái');setHistoryActorFilter('Tất cả người xử lý');setHistoryDateFilter('')}}>Xóa bộ lọc</button></div>}</div>
          <div className="history-panel-footer"><span><ShieldCheck size={14}/> Lịch sử được lưu trên trình duyệt hiện tại</span><span>Nhấn vào một dòng để xem chi tiết</span></div>
        </section>
      </> : <>
      <section className="page-heading"><div><div className="eyebrow"><span/> TRUNG TÂM AN NINH</div><h1>Quản lý cảnh báo</h1><p>Theo dõi, xác minh và xử lý các sự kiện an ninh trong khuôn viên trường.</p></div><div className="heading-meta"><div className="date-chip"><CalendarDays size={16}/><span>Thứ Bảy, 17 tháng 10, 2026</span></div><button className="outline-button" onClick={()=>{persist(initialAlerts);setSelectedId('AL-1048');clearFilters();setToast('Đã khôi phục dữ liệu demo');setTimeout(()=>setToast(''),2500)}}><RefreshCw size={15}/> Đặt lại demo</button></div></section>

      <section className="stats-grid">{stats.map(s=><div className="stat-card" key={s.label}><div className={`stat-icon ${s.tone}`}><s.icon size={19}/></div><div><span>{s.label}</span><strong>{String(s.value).padStart(2,'0')}</strong></div><div className="stat-accent"/></div>)}</section>

      <section className="workspace">
        <div className="list-panel">
          <div className="panel-header"><div><h2><BellRing size={19}/> Danh sách cảnh báo</h2><p>Các sự kiện được AI phát hiện gần đây</p></div><button className={`filter-toggle ${showFilters?'selected':''}`} onClick={()=>setShowFilters(v=>!v)}><SlidersHorizontal size={16}/> Bộ lọc <span>{[statusFilter!=='Tất cả trạng thái',severityFilter!=='Tất cả mức độ',typeFilter!=='Tất cả loại',!!dateFilter].filter(Boolean).length || ''}</span></button></div>
          <div className="search-row"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Tìm mã, loại cảnh báo, vị trí camera..."/>{query&&<button onClick={()=>setQuery('')}><X size={15}/></button>}</div><button className="filter-icon-button" onClick={()=>setShowFilters(v=>!v)}><Filter size={17}/></button></div>
          {showFilters&&<div className="filters">
            <label>Trạng thái<select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}><option>Tất cả trạng thái</option>{statusOptions.map(s=><option key={s}>{s}</option>)}</select></label>
            <label>Mức độ<select value={severityFilter} onChange={e=>setSeverityFilter(e.target.value)}><option>Tất cả mức độ</option><option>Cao</option><option>Trung bình</option><option>Thấp</option></select></label>
            <label>Loại cảnh báo<select value={typeFilter} onChange={e=>setTypeFilter(e.target.value)}><option>Tất cả loại</option>{[...new Set(alerts.map(a=>a.type))].map(t=><option key={t}>{t}</option>)}</select></label>
            <label>Ngày phát hiện<input type="date" value={dateFilter} onChange={e=>setDateFilter(e.target.value)}/></label>
            <button className="clear-filters" onClick={clearFilters}>Xóa bộ lọc</button>
          </div>}
          <div className="list-meta"><span>{filtered.length} cảnh báo được tìm thấy</span><button onClick={()=>setHistoryOnly(v=>!v)} className={historyOnly?'text-button active-text':''}><History size={14}/>{historyOnly?'Xem tất cả':'Ưu tiên có lịch sử'}</button></div>
          <div className="alert-list">
            {(historyOnly?filtered.filter(a=>a.history.length>1):filtered).map(a=>{const AIcon=iconFor(a.category);return <button key={a.id} className={`alert-row ${selectedId===a.id?'chosen':''}`} onClick={()=>{setSelectedId(a.id);setMobileDetail(true)}}><div className={`row-icon ${severityClass(a.severity)}`}><AIcon size={19}/></div><div className="row-content"><div className="row-title-line"><strong>{a.type}</strong><span className={`severity-dot ${severityClass(a.severity)}`}/></div><div className="row-location"><MapPin size={13}/>{a.location}</div><div className="row-bottom"><span className="alert-id">{a.id}</span><span><Clock3 size={12}/>{a.time}</span></div></div><div className="row-right"><span className={`status-pill ${statusClass(a.status)}`}>{a.status}</span><ChevronRight size={16}/></div></button>})}
            {filtered.length===0&&<div className="empty-state"><Search size={26}/><b>Không tìm thấy cảnh báo</b><span>Thử thay đổi từ khóa hoặc bộ lọc.</span><button onClick={clearFilters}>Xóa bộ lọc</button></div>}
            {historyOnly&&filtered.length>0&&filtered.filter(a=>a.history.length>1).length===0&&<div className="empty-state"><History size={24}/><b>Chưa có lịch sử xử lý</b><span>Các cảnh báo chưa có thao tác xử lý sẽ không xuất hiện ở đây.</span></div>}
          </div>
          <div className="list-footer"><span>Đang hiển thị dữ liệu demo</span><span><span className="green-dot"/> Đồng bộ vừa xong</span></div>
        </div>

        <div className={`detail-panel ${mobileDetail?'mobile-open':''}`}>
          {selected&&<><div className="detail-header"><div><div className="detail-kicker">CHI TIẾT SỰ KIỆN <span>•</span> {selected.id}</div><h2>{selected.type}</h2></div><button className="close-detail" onClick={()=>setMobileDetail(false)}><X size={18}/></button></div>
          <div className="alert-visual"><div className="visual-grid"/><div className="camera-label"><Camera size={14}/> {selected.camera} <span>● LIVE</span></div><div className="visual-center"><div className="visual-ring"><Icon size={35}/></div><strong>Hình ảnh sự kiện</strong><span>Chưa kết nối nguồn camera thực tế</span></div><div className="visual-footer"><span><Clock3 size={13}/> {selected.time}</span><span><MapPin size={13}/> {selected.location}</span></div></div>
          <div className="detail-status-line"><span className={`severity-badge ${severityClass(selected.severity)}`}><span/> Mức độ {selected.severity.toLowerCase()}</span><span className={`status-pill ${statusClass(selected.status)}`}>{selected.status}</span></div>
          <p className="description">{selected.description}</p>
          <div className="detail-info-grid"><div><span>Thời gian phát hiện</span><b><Clock3 size={14}/>{selected.date.split('-').reverse().join('/')} · {selected.time}</b></div><div><span>Vị trí</span><b><MapPin size={14}/>{selected.location}</b></div><div><span>Camera</span><b><Camera size={14}/>{selected.camera}</b></div><div><span>Độ tin cậy AI</span><b><Activity size={14}/>{selected.confidence}%</b></div></div>
          <div className="section-divider"/><div className="section-title"><h3><History size={17}/> Lịch sử xử lý</h3><span>{selected.history.length} hoạt động</span></div>
          <div className="timeline">{[...selected.history].reverse().map((h,i)=><div className="timeline-item" key={i}><div className={`timeline-marker ${i===0?'latest':''}`}>{i===0?<CircleDot size={13}/>:<Check size={12}/>}</div><div className="timeline-body"><div className="timeline-top"><b>{h.action}</b><time>{h.time}</time></div><p>{h.note}</p><span className="timeline-actor">{h.actor}</span></div></div>)}</div>
          <div className="update-box"><div className="update-title"><span><Activity size={16}/> Cập nhật xử lý</span><span className="required">* Bắt buộc ghi lịch sử</span></div><label htmlFor="note">Ghi chú xử lý <span>(không bắt buộc)</span></label><textarea id="note" value={note} onChange={e=>setNote(e.target.value)} placeholder="Nhập nội dung xác minh hoặc kết quả xử lý..."/><div className="status-actions"><label htmlFor="statusSelect">Trạng thái mới</label><select id="statusSelect" value={selected.status} onChange={e=>updateStatus(e.target.value)}>{statusOptions.map(s=><option key={s}>{s}</option>)}</select><button className="primary-button" onClick={()=>updateStatus(selected.status)}><CheckCircle2 size={16}/> Lưu cập nhật</button></div><p className="privacy-note"><ShieldCheck size={14}/> Mọi cập nhật đều được ghi vào lịch sử xử lý trên thiết bị này.</p></div>
          </>}
        </div>
      </section>
      <footer className="footer"><span>© 2026 SchoolGuard AI <i/> Bản demo quản lý an ninh trường học</span><span><ShieldCheck size={14}/> Quyền riêng tư được ưu tiên</span></footer>
      </>}
    </main>
    {toast&&<div className="toast"><CheckCircle2 size={18}/>{toast}</div>}
  </div>;
}

export default App;